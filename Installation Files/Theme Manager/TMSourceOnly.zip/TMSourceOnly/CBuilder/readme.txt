
All the enclosed headers are from the November 2001 Edition of the Microsoft� Platform Software Development Kit (SDK). These headers are directly or indirectly related to WinXP's visual styles APIs.

Schemadef.h
Tmschema.h
Uxtheme.h

The new version of 'CommCtrl.h' which contains related XP visual style stuff.

Headers listed in the includes of Schemadef, Tmschema and Uxtheme: 
PrSht.h
PshPack4.h
PshPack8.h

------------------------------------Documentation----------------------------
MSDN links

New SDK overview
<http://msdn.microsoft.com/library/en-us/sdkintro/relnotes_2ui3.asp?frame=true>

Information on whats new in 'CommCtrl.h'
<http://msdn.microsoft.com/library/default.asp?url=/library/en-us/shellcc/platform/commctls/common/common.asp>

XP Visual Styles
<http://msdn.microsoft.com/library/en-us/shellcc/platform/commctls/userex/themes.asp?frame=true>

<http://msdn.microsoft.com/library/en-us/dnwxp/html/xptheming.asp?frame=true>